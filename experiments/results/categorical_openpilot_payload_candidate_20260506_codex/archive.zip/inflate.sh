#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
"${PYTHON:-python3}" runtime_consumer.py --archive-root . --json-out runtime_consumer_report.json >/dev/stderr
echo 'categorical payload candidate is fail-closed: decode/re-encode and exact eval missing' >&2
exit 2
