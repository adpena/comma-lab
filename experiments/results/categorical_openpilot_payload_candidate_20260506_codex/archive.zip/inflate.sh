#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 runtime_consumer.py --archive-root . >/dev/stderr || true
echo 'categorical payload candidate is fail-closed: decode/re-encode and runtime parity missing' >&2
exit 2
