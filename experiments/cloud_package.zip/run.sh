#!/bin/bash
set -euo pipefail
export PYTHONPATH="$(pwd)/src:$(pwd)/upstream:$PYTHONPATH"
export PYTHONUNBUFFERED=1

TAG="${TAG:-cloud_h64_standard}"
HIDDEN="${HIDDEN:-64}"
EPOCHS="${EPOCHS:-2500}"
LOSS="${LOSS:-standard}"
TEMP_START="${TEMP_START:-1.0}"
TEMP_END="${TEMP_END:-0.05}"

echo "=== Training: tag=$TAG h=$HIDDEN epochs=$EPOCHS loss=$LOSS ==="

python3 train_tac.py     --tag "$TAG"     --hidden "$HIDDEN"     --epochs "$EPOCHS"     --loss-mode "$LOSS"     --temperature-start "$TEMP_START"     --temperature-end "$TEMP_END"     --alpha 20     --sal-lambda 1.0     --subsample 4     --output-dir ./weights     --archive ./archive.zip     --gt-video ./upstream/videos/0.mkv     --saliency ./saliency.npy     --models-dir ./upstream/models     --upstream-dir ./upstream
